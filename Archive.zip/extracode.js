function newArray() {
	var radnomArray = Array.from({length: 3}, () => Math.floor(Math.random() * 3));
	document.getElementById('AfterDisplay').innerHTML = after[randomArray[1]];
}

document.getElementById('AfterArray').innerHTML = after[arr[0]];



function newCandidate() {
	var randomAfter = Math.floor(Math.random() * after.length);
	document.getElementById('AfterDisplay').innerHTML = after[randomAfter];

	var randomRep = Math.floor(Math.random() * reputation.length);
	document.getElementById('RepDisplay').innerHTML = reputation[randomRep]; 

	var randomAstro = Math.floor(Math.random() * astro.length);
	document.getElementById('AstroDisplay').innerHTML = astro[randomAstro];
}

function newArray() {
	var AfterArr = [];
	for (var i=1; i<=playercount; i++) {
    	arr.push(Math.round(Math.random() * after.length))
	}
}

function GetCandidates {
	for (i = 0; i < AfterArr.length; i++){
	document.getElementById('AfterArray').innerHTML = after[arr[i]]

	}
}

	let randomIndex = getRandomNumber(1,AfterArray.length-1);
	let randomNumber = AfterArray[randomIndex]
	AfterArray.splice(randomIndex,1)

function getRandomNumber(min, max){
	let step1 = max - min + 1;
	let step2 = Math.random() * step1;
	let result = Math.floor(step2) + min;
	return result;
}

function CreateAfterArray(start, end){
	let myArray = [];

	for(let i = start; i<= end; i++){
		myArray.push(i)
	}

	return myArray;
}

function CreateRepArray(start, end){
	let myArray = [];

	for(let i = start; i<= end; i++){
		myArray.push(i)
	}

	return myArray;
}

function CreateAstroArray(start, end){
	let myArray = [];

	for(let i = start; i<= end; i++){
		myArray.push(i)
	}

	return myArray;
}



	after2.innerText = AfterArray[1]
	astro2.innerText = AstroArray[1]
	rep2.innerText = RepArray[1]

	after3.innerText = AfterArray[2]
	astro3.innerText = AstroArray[2]
	rep3.innerText = RepArray[2]