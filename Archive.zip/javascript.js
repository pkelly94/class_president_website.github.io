let id = document.querySelector('#id_prompt');
let br = document.querySelector('#br_wall');

var after = [
	'chess club',
	'varsity sport',
	'debate team',
	'marching band',
	'cheerleading team',
	'drama club',
	'art club',
	'stoner',
	'church youth group',
	'young entrepreneurs',
	'scouts',
	'equestrian club',
	'fry cook',
	'anime club'
]

var rep = [
	'home schooled until high school',
	'designated driver',
	'has rich parents',
	'has a cool older sibling',
	'was held back',
	'took acid once',
	'instagram model',
	'came back from summer break really hot',
	'in a garage band',
	'school bully',
	'army brat',
	'performs slam poetry',
	'spiritual, not religious',
	'can do a kickflip',
	'school mascot',
	'child actor',
	'you are a communist, comrade!',
	'soundcloud rapper',
	'has a face tattoo',
	'slut',
	'flower child',
	'teachers pet',
	'used to be popular',
	'loner',
	'class sweetheart',
	'goth',
	'allergic to everything',
	'woke af',
	'always in the friend zone',
	'devout atheist',
	'avid gamer',
	'libertarian'
]

var astro = [
	'leo',
	'aquarius',
	'virgo',
	'libra',
	'cancer',
	'gemini',
	'taurus',
	'capricorn',
	'pisces',
	'aries',
	'scorpio',
	'sagittarius'
]

var rumor = [
	'sells fake drugs to freshman',
	'is a reclaimed virgin',
	'has a 30 yr old s/o',
	'only hooks up w/ freshman',
	'hooked up with bffs s/o',
	'broke up w/ person to their left via text',
	'ghosted person to their right',
	'bought their instagram followers',
	'still believes in santa',
	'slept with a teacher',
	's/o from camp is fake',
	'has a shrine in their closet for the person to their left',
	'sent nudes to the principal',
	'has never been kissed',
	'made out with a hot dog',
	'is cheating on s/o with person to their right',
	'parents wont let them watch pg-13 rated movies',
	'is always wearing a g string',
	'has vodka in their water bottle',
	'was on the show teen mom',
	'cried when they didnt get into hogwarts',
	'has a spray tan',
	'masturbates in the 3rd floor bathroom',
	'really wants to talk about the summer reading assignment',
	'bought a love potion online',
	'has a secret youtube channel they dont want the school knowing about',
	'has been arrested',
	'is a serial monogamist',
	'has an onlyfans account',
	'is a(n) [insert culturally relevant event] truther',
]

var playercount = document.getElementById("myNumber").value;

function shuffle(array) {
    var i = array.length,
        j = 0,
        temp;

    while (i--) {

        j = Math.floor(Math.random() * (i+1));

        // swap randomly chosen element with current element
        temp = array[i];
        array[i] = array[j];
        array[j] = temp;

    }

    return array;
}

function getElement(array, x) {
	for(var i=0; i<=x; i++){
		let element = document.querySelector('#'+array[i])
		element.innerText = astro[0]
		return element
	}
}

function Hide(array) {
	for(var i=0;i<=8;i++){
		let element = document.querySelector('#'+array[i])
		element.style.visibility = "hidden"
	}
  }

function Show(array, x) {
	for(var i=0;i<=x-1;i++){
		let element = document.querySelector('#'+array[i])
		element.style.visibility = "visible"
	}
  }


var allDivArray = [
	'p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7', 'p8', 'p9'
]

var elementafterarray = [
	'after1', 'after2', 'after3', 'after4', 'after5', 'after6', 'after7', 'after8', 'after9'
]

var elementreparray = [
	'rep1', 'rep2', 'rep3', 'rep4', 'rep5', 'rep6', 'rep7', 'rep8', 'rep9'
]

var elementastroarray = [
	'astro1', 'astro2', 'astro3', 'astro4', 'astro5', 'astro6', 'astro7', 'astro8', 'astro9'
]

var allelements = [
	'after1', 'after2', 'after3', 'after4', 'after5', 'after6', 'after7', 'after8', 'after9',
	'rep1', 'rep2', 'rep3', 'rep4', 'rep5', 'rep6', 'rep7', 'rep8', 'rep9',
	'astro1', 'astro2', 'astro3', 'astro4', 'astro5', 'astro6', 'astro7', 'astro8', 'astro9'
]


id.addEventListener('click', () =>{

// define player count
	
	var playercount = document.getElementById("myNumber").value;	
	
	let error = document.querySelector('#error')
	
	error.style.visibility = "hidden";
	
	if (playercount < 2) {
		
		let element = document.querySelector('#error')
		element.style.visibility = "visible"
		element.innerText = "that doesn't look like much of a democracy, please enter a value between 2 and 9"
		
	} else if (playercount > 9) {
		
		let element = document.querySelector('#error')
		element.style.visibility = "visible"
		element.innerText = "having "+playercount+" friends is impressive but it is time to pick your favorites, please enter a value between 2 and 9"
		
	} else {
		
		// Define arrays
	
		let AstroArray = shuffle(astro);
		let AfterArray = shuffle(after);
		let RepArray = shuffle(rep);

		// clear all elements	
	
		Hide(allDivArray)
		Show(allDivArray, playercount)
	
		for(var i=1; i<=9; i++){
			let element = document.querySelector('#'+allelements[i-1]);
			element.innerText = '';
		}
	
		// Get After School Activities
	
		for(i=1; i<=playercount; i++){
			let element = document.querySelector('#'+elementafterarray[i-1]);
			element.innerText = AfterArray[i-1];
		}
	
		// Get Astrological Sign
	
		for(i=1; i<=playercount; i++){
			let element = document.querySelector('#'+elementastroarray[i-1]);
			element.innerText = AstroArray[i-1];
		}

		// Get Reputations

		for(i=1; i<=playercount; i++){
			let element = document.querySelector('#'+elementreparray[i-1]);
			element.innerText = RepArray[i-1];
			}		
		}
});





br.addEventListener('click', () =>{

// define player count
	
	var playercount = document.getElementById("myNumber").value;	
	
	let error = document.querySelector('#error')
	
	error.style.visibility = "hidden";
	
	if (playercount < 2) {
		
		let element = document.querySelector('#error')
		element.style.visibility = "visible"
		element.innerText = "that doesn't look like much of a democracy, please enter a value between 2 and 9"
		
	} else if (playercount > 9) {
		
		let element = document.querySelector('#error')
		element.style.visibility = "visible"
		element.innerText = "having "+playercount+" friends is impressive but it is time to pick your favorites, please enter a value between 2 and 9"
		
	} else {
		
		// Define arrays
	
		let RumorArray = shuffle(rumor);

		// clear all elements	
	
		Hide(allDivArray)
		Show(allDivArray, playercount)
	
		for(var i=1; i<=27; i++){
			let element = document.querySelector('#'+allelements[i-1]);
			element.innerText = '';
		}
	
		// Get Rumors
	
		for(i=1; i<=playercount; i++){
			let element = document.querySelector('#'+elementastroarray[i-1]);
			element.innerText = RumorArray[i-1];
		}
		
	}
});

// console.log(getElement(elementafterarray, playercount));