// JavaScript Document

let btn = document.querySelector('button');

var rumor = [
	'sells fake drugs to freshman',
	'is a reclaimed virgin',
	'has a 30 yr old s/o',
	'only hooks up w/ freshman',
	'hooked up with bffs s/o',
	'stole e cig from another player',
	'broke up w/ person to their left via text',
	'ghosted person to their right',
	'bought their instagram followers',
	'still believes in santa',
	'slept with a teacher',
	's/o from camp is fake',
	'has a shrine in their closet for the person to their left',
	'sent nudes to the principal',
	'has never been kissed',
	'made out with a hot dog',
	'is cheating on s/o with person to their right',
	'parents wont let them watch pg-13 rated movies',
	'is always wearing a g string thong',
	'has vodka in their water bottle',
	'was on the show teen mom',
	'cried when they didnt get into hogwarts',
	'has a spray tan',
	'masturbates in the 3rd floor bathroom',
	'really wants to talk about the summer reading assignment',
	'bought a love potion online',
	'has a secret youtube channel they dont want the school knowing about',
	'has been arrested',
	'is a serial monogamist',
	'has an onlyfans account',
	'is an [insert culturally relevant event] truther',
]

var playercount = document.getElementById("myNumber").value;

function shuffle(array) {
    var i = array.length,
        j = 0,
        temp;

    while (i--) {

        j = Math.floor(Math.random() * (i+1));

        // swap randomly chosen element with current element
        temp = array[i];
        array[i] = array[j];
        array[j] = temp;

    }

    return array;
}

function Hide(array) {
	for(var i=0;i<=8;i++){
		let element = document.querySelector('#'+array[i])
		element.style.visibility = "hidden"
	}
  }

function Show(array, x) {
	for(var i=0;i<=x-1;i++){
		let element = document.querySelector('#'+array[i])
		element.style.visibility = "visible"
	}
  }


var allPArray = [
	'b1', 'b2', 'b3', 'b4', 'b5', 'b6', 'b7', 'b8', 'b9'
]

btn.addEventListener('click', () =>{

// define player count
	
	var playercount = document.getElementById("myNumber").value;	
	
	let error = document.querySelector('#error')
	error.style.visibility = "hidden";
	
	// clear all elements	
	
	Hide(allPArray)
	Show(allPArray, playercount)
	
	for(var i=1; i<=9; i++){
		let element = document.querySelector('#'+allPArray[i-1]);
		element.innerText = '';
	}
	
	if (playercount < 2) {
		
		let element = document.querySelector('#error')
		element.style.visibility = "visible"
		element.innerText = "that doesn't look like much of a democracy, please enter a value between 2 and 9"
		
	} else if (playercount > 9) {
		
		let element = document.querySelector('#error')
		element.style.visibility = "visible"
		element.innerText = "having "+playercount+" friends is impressive but it is time to pick your favorites, please enter a value between 2 and 9"
		
	} else {
		
		// Define arrays
	
		let RumorArray = shuffle(rumor);
	
		// Get Rumors
	
		for(var i=1; i<=playercount; i++){
			let element = document.querySelector('#'+allPArray[i-1]);
			element.innerText = RumorArray[i-1];
		}
	}
});